function navegar(){
    window.location = "https://www.google.com.br/?hl=pt-BR";
}